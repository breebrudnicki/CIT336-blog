<?php include '../view/header.php'; ?>

<main>
    <h2>Register Product</h2>
    <!--Display a message that says the product code that has been registered-->
    <?php echo "Product $product_code was registered successfully"; ?>
</main>

<?php include '../view/footer.php'; ?>