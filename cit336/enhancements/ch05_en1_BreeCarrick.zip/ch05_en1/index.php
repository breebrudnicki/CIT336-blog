<?php include 'view/header.php'; ?>
<main>
    <h1>Menu</h1>
    <ul>
        <li>
            <a href="product_manager">Product Manager</a>
        </li>
        <li>
            <a href="product_catalog">Product Catalog</a>
        </li>
    </ul>
</main>
<?php include 'view/footer.php'; ?>