    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <!--verify website with pinterest-->
    <meta name="p:domain_verify" content="ac887fc0675d2aed16f1d228b571a0ed"/>
    <!-- Bootstrap -->
	<link href="/blog/css/bootstrap.css" rel="stylesheet"/>
	<link href="/blog/css/bootstrap-3.3.5.css" rel="stylesheet" type="text/css"/>
    <!-- Bree's CSS -->
    <link href="/blog/css/styles.css" rel="stylesheet" type="text/css" />
	<!--google font-->
    <link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet" type="text/css">
