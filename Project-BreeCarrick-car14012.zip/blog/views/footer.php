<footer id="footer">
	  <div class="row">
        <div class="col-sm-6 footerone">
        <p class="breefooter">Bree Carrick</p>
        <p>&copy; 2016 Bree Carrick</p>
        <p>
            <a href="https://www.pinterest.com/BreeCarrick/" target="_blank" class="socialmedia">
                <img src="/images/pinterest-01.png" alt="pinterest" width="50" height="50" class="socialmedia"/>
            </a>
            <a href="https://www.instagram.com/breetato/" target="_blank">
                <img src="/images/instagram-03.png" alt="" width="50" height="50" class="socialmedia"/>
            </a><a href="https://www.linkedin.com/in/breecarrick" target="_blank">
                <img src="/images/linkedin-02.png" alt="" width="50" height="50" class="socialmedia"/>
            </a>
            <a href="/index.php#contact">
                <img src="/images/email-04.png" alt="" width="50" height="50" class="socialmedia"/>
            </a>
        </p>
      </div>
        <div class="col-sm-6">
          <ul>
            <li><a href="/index.php#about">About</a></li>
            <li><a href="/resume.php">Resume</a></li>
            <li><a href="/contact/index.php">Contact</a></li>
            <li><a href="/portfolio.php">Portfolio</a></li>
            <li><a href="/blog/index.php">Blog</a></li>
            <li><a href="/cit336/index.php">CIT 336 Exercises</a></li>
            <li><a href="/cit336/teachingpresentation/index.php">CIT 336 Teaching Presentation</a></li>
            <li><a href="/blog/admin.php">Blog Admin Login</a></li>
            <li><a href="/cit336/walkthrough.php">Project Walkthrough</a></li>
          </ul>
        </div>
      </div>
	</footer>